function men() {
  document.getElementById('main').classList.toggle('open');
}

function lan() {
  document.getElementById('lang-list').classList.toggle('block');
}
